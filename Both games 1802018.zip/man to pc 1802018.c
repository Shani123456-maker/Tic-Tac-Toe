#include<stdio.h>
#include<time.h>
void game(char array[3][3]);
void play(char array[3][3]);
void win1(char aray[3][3]);
int main()
{
    printf("Computer's mark is X\n");

    printf("Player  mark is 0\n");
    printf("If a player tries to fill the already filled block\n then he would be given another chances to fill the empty one\n");
      printf("You are also offered to play more games\n");
    char b;
    do{
    char arr[3][3];
    for(int x=0; x<3; x++)
    {
        for(int y=0; y<3; y++)
        {
            arr[x][y]='_';
        }

    }

    game(arr);
    play(arr);
    printf("Press to P to play again or any other key to terminate\n");
    scanf(" %c",&b);
    }while(b=='P');
}

void game(char array[3][3])
{


    for(int x=0; x<3; x++)
    {
        for(int y=0; y<3; y++)
        {
            printf(" %c",array[x][y]);
        }
        printf("\n");

    }

}

void play(char array[3][3])
{ srand(time(0));
    int x,y,b=0;
    char z;
    for(int a=0;a<=4;a++)
    {
        do
        {
            z='0';
            x=rand()%3;
            y=rand()%3;
            printf("Computer's turn\n");
            if(array[x][y]=='_')
            {

                array[x][y]='X';
                printf("\n");
                game(array);
                printf("\n");

            }

            else
            {
           z='A';
            }
        }
        while(z=='A');

        if(array[0][0]=='X' &&array[0][0]==array[0][1] && array[0][1]==array[0][2] ||
                array[1][0]=='X' &&array[1][0]==array[1][1] && array[1][1]==array[1][2] ||
                array[2][0]=='X' &&array[2][0]==array[2][1] && array[2][1]==array[2][2] ||
                array[0][0]=='X' &&array[0][0]==array[1][0] && array[1][0]==array[2][0] ||
                array[0][1]=='X' &&array[0][1]==array[1][1] && array[1][1]==array[2][1] ||
                array[0][2]=='X' &&array[0][2]==array[1][2] && array[1][2]==array[2][2] ||
                array[0][0]=='X' &&array[0][0]==array[1][1] && array[1][1]==array[2][2] ||
                array[0][2]=='X' &&array[0][2]==array[1][1] && array[1][1]==array[2][0]
          )
        {

            printf("         Sorry\n");
            printf("        Computer won the game\n");
            break ;

        }

if(b<4){
        do
        {

            z='0';
            printf("Player  turn\n");
            printf("Enter X and Y position of index\n");
            scanf("%d %d",&x,&y);
            if(array[x][y]=='_')
            {
                array[x][y]='0';
                printf("\n");
                game(array);
                printf("\n");
                b++;


            } // inserting if
            else
            {
                printf("Presss A to try again place was already holded\n");
                scanf(" %c",&z);
            } // try again
        } // ending do loop
        while(z=='A');

        if(array[0][0]=='0' &&array[0][0]==array[0][1] && array[0][1]==array[0][2] ||
                array[1][0]=='0' &&array[1][0]==array[1][1] && array[1][1]==array[1][2] ||
                array[2][0]=='0' &&array[2][0]==array[2][1] && array[2][1]==array[2][2] ||
                array[0][0]=='0' &&array[0][0]==array[1][0] && array[1][0]==array[2][0] ||
                array[0][1]=='0' &&array[0][1]==array[1][1] && array[1][1]==array[2][1] ||
                array[0][2]=='0' &&array[0][2]==array[1][2] && array[1][2]==array[2][2] ||
                array[0][0]=='0' &&array[0][0]==array[1][1] && array[1][1]==array[2][2] ||
                array[0][2]=='0' &&array[0][2]==array[1][1] && array[1][1]==array[2][0]
          ) //if statement
        {
            printf("         Congrates\n");
            printf("        Player  won the game\n");
            break ;

        } // ending of win while loop
} else printf("Game tied no one won the game");
        } // ending of for loop






    } //ending of play function


